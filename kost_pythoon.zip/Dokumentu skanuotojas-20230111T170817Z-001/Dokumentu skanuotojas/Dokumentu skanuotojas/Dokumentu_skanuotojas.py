import cv2
import numpy as np
import utils


########################################################################
webCamFeed = False
pathImage = "3.jpg" ##pasirenkame kokia nuotrauka norime skenuoti
cap = cv2.VideoCapture(0) ##prasideda kamera
cap.set(10, 160)
aukstis = 640 ##pasirenkame nuotraukos dydzius
plotis = 480 ##pasirenkame nuotraukos dydzius
########################################################################

utils.initializeTrackbars()
count=0
while True:

    if webCamFeed:success, img = cap.read()
    else:img = cv2.imread(pathImage)
       #Pakeisti paveiksliuko dydį į specifinius matmenis
    img = cv2.resize(img, (plotis, aukstis))
      #Sukurti tuščią paveiksliuką tokiu pat dydžiu kaip ir "img"
    imgBlank = np.zeros((aukstis, plotis, 3), np.uint8)
       #Konvertuoti paveiksliuką į atspalvų atvaizdą
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      #Taikyti Gaußo maišymo filtrą sumažinti triukšmą paveiksliuke
    imgBlur = cv2.GaussianBlur(imgGray, (5, 5), 1)
     #Nuskaityti slenkstinės vertes iš trackbar'ų
    thres = utils.valTrackbars()
     #Taikyti kraštinių nustatymo Canny algoritmą su nuskaitytomis slenkstinėmis vertėmis
    imgThreshold = cv2.Canny(imgBlur, thres[0], thres[1])

     #Sukurti kernelą plitimui ir erozijai
    kernel = np.ones((5, 5))

      #Taikyti plitimą ir eroziją kontūrų kokybės gerinimui
    imgDial = cv2.dilate(imgThreshold, kernel, iterations=2)
    imgThreshold = cv2.erode(imgDial, kernel, iterations=1)
       #Sukurti originalaus paveiksliuko kopiją kontūrams piešti
    imgContours = img.copy()
    imgBigContour = img.copy()

     #Rasti paveiksliuke kontūrus
    contours, hierarchy = cv2.findContours(imgThreshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

      #Sukurti kopiją orginalaus paveiksliuko
    imgContours = img.copy()
     #Sukurti kopiją orginalaus paveiksliuko, kuris bus naudojamas norint nustatyti didžiausią kontūrą
    imgBigContour = img.copy()
        #Nubrėžti kontūrus ant paveiksliuko kopijos
    contours, hierarchy = cv2.findContours(imgThreshold, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(imgContours, contours, -1, (0, 255, 0), 10)




     #Rasti didžiausią kontūrą
    biggest, maxArea = utils.biggestContour(contours)
    if biggest.size != 0:
        biggest=utils.reorder(biggest)
        cv2.drawContours(imgBigContour, biggest, -1, (0, 255, 0), 20) #Nubrėžti didžiausią kontūrą
        imgBigContour = utils.drawRectangle(imgBigContour,biggest,2) #Nubrėžti stačiakampį aplink didžiausią kontūrą
        pts1 = np.float32(biggest) #Apskaičiuoti transformacijos matricą
        pts2 = np.float32([[0, 0],[plotis, 0], [0, aukstis],[plotis, aukstis]])
        matrix = cv2.getPerspectiveTransform(pts1, pts2)
        imgWarpColored = cv2.warpPerspective(img, matrix, (plotis, aukstis)) #Perspektyvinė transformacija


        imgWarpColored=imgWarpColored[20:imgWarpColored.shape[0] - 20, 20:imgWarpColored.shape[1] - 20] #Patrumpinti perspektyvinio transformuoto paveiksliuko kraštus
        imgWarpColored = cv2.resize(imgWarpColored,(plotis,aukstis))  #Redaguoti perspektyvinio transformuoto paveiksliuko dydį


        imgWarpGray = cv2.cvtColor(imgWarpColored,cv2.COLOR_BGR2GRAY) #Paversti perspektyvinio transformuotą paveiksliuką į pilką
        imgAdaptiveThre= cv2.adaptiveThreshold(imgWarpGray, 255, 1, 1, 7, 2) #Adaptyviuosius slenkstinio reikšmės nustatymus paveiksliuke
        imgAdaptiveThre = cv2.bitwise_not(imgAdaptiveThre) #Pakeisti bitų reikšmes paveiksliuke
        imgAdaptiveThre=cv2.medianBlur(imgAdaptiveThre,3) #Suminkštinti paveiksliuką


        imageArray = ([img,imgGray,imgThreshold,imgContours],
                      [imgBigContour,imgWarpColored, imgWarpGray,imgAdaptiveThre])
    else:
        imageArray = ([img,imgGray,imgThreshold,imgContours],
                      [imgBlank, imgBlank, imgBlank, imgBlank])


    lables = [["Originali","Pilka","erozija","Konturai"],
              ["ryskiausi konturai","Warp perpektyva","Warp Pilka","adaptuota erozija"]]

    stackedImage = utils.stackImages(imageArray,0.75,lables)
    cv2.imshow("Resultatas",stackedImage)


    if cv2.waitKey(1) & 0xFF == ord('X'):##pasirenkame su kokiu mygtuku issisaugosim nuskenuota dokumenta
        cv2.imwrite("C:\Program Files\scan"+str(count)+".jpg",imgWarpColored)
        cv2.rectangle(stackedImage, ((int(stackedImage.shape[1] / 2) - 230), int(stackedImage.shape[0] / 2) + 50),
                      (1100, 350), (0, 255, 0), cv2.FILLED)
        cv2.putText(stackedImage, "ISSAUGOTA > C:\Program Files\scan", (int(stackedImage.shape[1] / 2) - 150, int(stackedImage.shape[0] / 2)),
                    cv2.FONT_HERSHEY_DUPLEX, 3, (0, 0, 255), 5, cv2.LINE_AA)
        cv2.imshow('Rezultatas', stackedImage)
        cv2.waitKey(300)
        count += 1

